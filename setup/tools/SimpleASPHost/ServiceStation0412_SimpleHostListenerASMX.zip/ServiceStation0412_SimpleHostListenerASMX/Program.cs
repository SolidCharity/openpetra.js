﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Hosting;
using System.Net;
using System.IO;
using System.Reflection;

namespace SimpleHost
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string physicalDir = Directory.GetCurrentDirectory();
                
                if (!(physicalDir.EndsWith("\\")))
                        physicalDir = physicalDir + "\\";
 
                // Copy this hosting DLL into the /bin directory of the application
                string FileName = Assembly.GetExecutingAssembly().Location;

                try
                {
                    if (!Directory.Exists(physicalDir + "bin\\"))
                        Directory.CreateDirectory(physicalDir + "bin\\");
             
                    string JustFname = Path.GetFileName(FileName);
                    File.Copy(FileName, physicalDir + "bin\\" + JustFname, true);
                }
                catch { ;}                
                
                HttpListenerWrapper lw = (HttpListenerWrapper)ApplicationHost.CreateApplicationHost(
                    typeof(HttpListenerWrapper), "/", physicalDir);
    
                string port = "8888";
                string[] parameters = Environment.GetCommandLineArgs();
                if (parameters.Length > 1)
                {
                    port = parameters[1];
                }
                
                Console.WriteLine("trying to listen on port " + port);
                
                string[] prefixes = new string[] {
                                "http://+:" + port + "/"
                            };
                
                lw.Configure(prefixes, "/", Directory.GetCurrentDirectory());
                
                try
                {
                    lw.Start();
                }
                catch (HttpListenerException)
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("we cannot listen on this port. perhaps you need to run as administrator once: ");
                    Console.WriteLine("  netsh http add urlacl url=http://+:" + port + "/ user=" + Environment.MachineName + "\\" + Environment.UserName);
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    
                    throw;
                }
                Console.WriteLine("Listening for requests on http://127.0.0.1:" + port + "/");
                while (true)
                    lw.ProcessRequest();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
